import java.awt.*;
import hsa.Console;
import java.awt.print.*;
import javax.imageio.*;
import java.io.*;
import java.lang.String;
import sun.audio.*;

public class WS_FK_AK_OC_ICSSummative // Pin Code = 2-2-2-2 The first time
{
    static Console c;

    public static AudioStream as = null;

    //Sound and Images provided by Ali khan
    //Print logic, withdraw money option, deposit money option and menu for loops coded by syed wadood
    //choice for changing pincode and check bankbalance coded by Fahad Khan
    //Graphic user interface of the menu designed by Osama Chaudhary
    //Log in Menu by Fahad and security check by wadood
    //Start-up animation by Wadood
    //Assembled by Syed Wadood
    

    //Used for loading image
    public static Image loadImage (String name)  //Loads image from file
    {
	Image img = null;
	try
	{
	    img = ImageIO.read (new File (name));
	}
	catch (IOException e)
	{
	}
	return img;
    }
    

    public static void Player (String audioname)  // Audio player method
    {
	InputStream in = null;

	try
	{
	    in = new FileInputStream (new File (audioname));
	}
	catch (FileNotFoundException e)
	{
	}
	try
	{
	    as = new AudioStream (in);
	}
	catch (IOException e)
	{
	}
    }

    // These variables will not work, if declared in the main, (i.e inside the PrintMoney class), that's they are declared as public static
    // They are also declared as static because i want to call these variables from the PrintMoney class, and not just assign them to a specific instance of the class

    public static int withdrawnum, bankbalance = 0, choice, check = 0, checkhelper = 0, k = 0, deposit, p = 0; // The check and checkhelper var is used throughout the program to check if the program is running for the first time

    public static PrinterJob job = PrinterJob.getPrinterJob ();

    public static Image money5 = loadImage ("Dollar5.png"), money10 = loadImage ("Dollar10.png"), money20 = loadImage ("Dollar20.png"), money50 = loadImage ("Dollar50.png"), money100 = loadImage ("Dollar100.png"), pinicon = loadImage ("PinIcon.png"); //Declaring printable dollar bills as image variables

    public static void main (String[] args)
    {
	c = new Console (100, 140, "ATM_Summative");

	//Pincode values declared here
	char typedpin1 = '0', pinvalue1 = '2';
	char typedpin2 = '0', pinvalue2 = '2';
	char typedpin3 = '0', pinvalue3 = '2';
	char typedpin4 = '0', pinvalue4 = '2';

	//ATM GUI variables
	Color ATMtheme = new Color (75, 125, 225);

	//GUI Images
	Image wrongpin = loadImage ("wrongpincode.png"), right = loadImage ("TickMarkSymbol.png"), wrong = loadImage ("cancelicon.png"), angry = loadImage ("AngryEmoji.png"), withdrawal = loadImage ("WithdrawalIcon.png"), piggybank = loadImage ("PiggyBankSymbol.png"), balance = loadImage ("BankBalanceSymbol.png");   //ATM image Icon Variables

	//All print commands are sent here
	class PrintMoney
	    implements Printable
	{
	    public int print (Graphics g, PageFormat pf, int page)  //Code that starts with G such as g.setColor(); will appear on paper //Code that start with c such as c.println (); will appear in console windows
	    {
		if (page > 0)
		    return NO_SUCH_PAGE;

		//The Money Logic goes here, the logic is that the program checks if the input withdrawnumber is more or less than 100 ,if the withdrawnumber is more than 100
		//than it displays a $100 bill and then it checks if the input withdrawnumber is more or less than 50 and displays a $50 bill, if the input withdrawnumber is more
		//than 50. The program continues to check for the $20, $10 and $5 bill too.

		//Integers declared here
		int dollar100 = withdrawnum % 100;     //used to check if input withdrawnumber is more or less than 100
		int dollar50 = dollar100 % 50;         //used to check if input withdrawnumber is more or less than 50
		int dollar20 = dollar50 % 20;          //used to check if input withdrawnumber is more or less than 20
		int dollar10 = dollar20 % 10;          //used to check if input withdrawnumber is more or less than 10
		int dollar5 = dollar10 % 5;            //used to check if input withdrawnumber is more or less than 5

		if (withdrawnum == 200)
		{
		    g.drawImage (money100, 75, 125, null);
		    g.drawImage (money100, 325, 125, null);
		}

		if (withdrawnum == 100)
		{
		    g.drawImage (money100, 75, 125, null);
		}

		if (withdrawnum < 200 && withdrawnum > 100) //Checking if num is more than 100
		{
		    g.drawImage (money100, 75, 125, null);

		    //Checking to see if input withdrawnumber is more or less than 50
		    if (dollar100 >= 50)
		    {
			g.drawImage (money50, 75, 375, null);
		    }

		    //Checking to see if the input withdrawnumber is more or less than 20
		    if (dollar50 >= 20)
		    {
			g.drawImage (money20, 325, 375, null);
		    }

		    //Checking to see if the input withdrawnumber is more or less than 10
		    if (dollar20 >= 10)
		    {
			g.drawImage (money10, 75, 625, null);
		    }

		    //Checking to see if the input withdrawnumber is more or less than 5
		    if (dollar10 >= 5)
		    {
			g.drawImage (money5, 325, 625, null);
		    }

		    //Adding all the dollar bills will make 185 (100 + 50 + 20 + 10 + 5 = 185)
		    //so the code cannot print bills that make $185-$195
		    //this code is a solution to that problem, it prints the remaining bills

		    if (withdrawnum >= 190 && withdrawnum <= 194)
		    {
			g.drawImage (money20, 325, 125, null);
		    }
		    if (withdrawnum >= 195 && withdrawnum <= 199)
		    {
			g.drawImage (money20, 325, 125, null);
		    }

		    if (withdrawnum >= 145 && withdrawnum <= 149)
		    {
			g.drawImage (money20, 325, 125, null);
		    }

		    if (withdrawnum >= 140 && withdrawnum <= 144)
		    {
			g.drawImage (money20, 325, 125, null);
		    }
		}
		else if (withdrawnum < 100 && withdrawnum > 0) //if num is not more than 100 than do this
		{
		    //Checking to see if withdrawnumber is more or less than 50
		    if (dollar100 >= 50)
		    {
			g.drawImage (money50, 75, 375, null);
		    }

		    //Checking to see if the withdrawnumber is more or less than 20
		    if (dollar50 >= 20)
		    {
			g.drawImage (money20, 325, 375, null);
		    }

		    //Checking to see if the input withdrawnumber is more or less than 10
		    if (dollar20 >= 10)
		    {
			g.drawImage (money10, 75, 625, null);
		    }

		    //Checking to see if the input withdrawnumber is more or less than 5
		    if (dollar10 >= 5)
		    {
			g.drawImage (money5, 325, 625, null);
		    }

		    //Adding all the dollar bills will make 85 (50 + 20 + 10 + 5 = 85)
		    //so the code cannot print bills that make $85-95
		    //this code is a solution to that problem

		    if (withdrawnum >= 90 && withdrawnum <= 94)
		    {
			g.drawImage (money20, 325, 125, null);
		    }

		    if (withdrawnum >= 95 && withdrawnum <= 99)
		    {
			g.drawImage (money20, 325, 125, null);
		    }

		    if (withdrawnum >= 45 && withdrawnum <= 49)
		    {
			g.drawImage (money20, 325, 125, null);
		    }

		    if (withdrawnum >= 40 && withdrawnum <= 44)
		    {
			g.drawImage (money20, 325, 125, null);
		    }
		}


		return PAGE_EXISTS;
	    }
	}

	//Print money class ends here

	for (check = 1 ; check < 5 ; check++) //For loop used to loop the program when the number of tries to unlock the pincode are less than 5
	{
	    c.setColor (Color.gray);
	    c.fillRect (0, 0, 1150, 800);
	    c.setColor (Color.black);
	    c.fillRect (75, 75, 966, 550);
	    checkhelper++;

	    if (checkhelper == check)
	    {
		if (p != 3) //Code inside this will only run for the first time
		{
		    c.getChar ();
		    //Pressing button to Boot up ATM for first time
		    //Fader algorithm Starts here

		    int colperameter = 255;

		    double red = 0, green = 0, blue = 0;

		    c.clear ();
		    c.setColor (Color.gray);
		    c.fillRect (0, 0, 1150, 800);
		    c.setColor (ATMtheme);
		    c.fillRect (75, 75, 966, 550);

		    for (int perameter = 0 ; perameter <= 1000 ; perameter++)  //This loops a 10000 times so i divided the ATMtheme's Red, Green, Blue values separately with 10000
		    {
			int redint = (int) (red + 0.5);         //Converts the double variable to an integer so that it can be used as an RGB value
			int greenint = (int) (green + 0.5);
			int blueint = (int) (blue + 0.5);

			Color ATMtheme2 = new Color (redint, greenint, blueint);
			c.setColor (ATMtheme2);
			c.fillRect (75, 75, 966, 550);

			red = red + 0.075;     //every time the program loops (10000 times), this value is added to the previous value of the RGB colors
			green = green + 0.125; //The smaller the added number is, the slower the black image fades out
			blue = blue + 0.225;
		    }

		    AudioPlayer.player.stop (as); // stops all music //This is declared outside the for loop because i don't want the audio to play everytime the person logs out
		    Player ("Atm8.wav");
		    AudioPlayer.player.start (as); // starts music
		    //Fader algorithm ends here
		    p = 3; //So that this doesn't loop anytime else
		}

		c.clear ();
		c.setColor (Color.gray);
		c.fillRect (0, 0, 1150, 800);
		c.setColor (ATMtheme);
		c.fillRect (75, 75, 966, 550);

		c.setColor (Color.black);
		c.setFont (new Font ("TimesRoman", Font.PLAIN, 40));
		c.drawString ("WELCOME TO THE ROYAL BANK OF GARNEAU", 105, 175);
		c.setFont (new Font ("TimesRoman", Font.PLAIN, 30));
		c.drawString ("Please enter your 4-digit pin code", 355, 350);
		c.setColor (Color.white);
		c.fillRect (450, 398, 200, 50);
		c.setColor (Color.black);
		c.setFont (new Font ("TimesRoman", Font.PLAIN, 40));

		typedpin1 = c.getChar ();
		c.drawString ("*", 475, 443);
		typedpin2 = c.getChar ();
		c.drawString ("*", 520, 443);
		typedpin3 = c.getChar ();
		c.drawString ("*", 560, 443);
		typedpin4 = c.getChar ();
		c.drawString ("*", 603, 443);

		c.setFont (new Font ("TimesRoman", Font.PLAIN, 30));
		c.drawString ("Press any button to continue", 380, 535);
		c.getChar ();
		AudioPlayer.player.stop (as); // stops all music
		c.clear ();

		if (typedpin1 != pinvalue1 || typedpin2 != pinvalue2 || typedpin3 != pinvalue3 || typedpin4 != pinvalue4)
		{
		    c.clear ();
		    AudioPlayer.player.stop (as); // stops all music
		    try
		    {
			Player ("Atmsound1.wav");
			AudioPlayer.player.start (as); // starts music
		    }
		    catch (Exception e)
		    {
		    }
		    c.setColor (Color.gray);
		    c.fillRect (0, 0, 1600, 800);
		    c.setColor (ATMtheme);
		    c.fillRect (75, 75, 966, 550);
		    c.setColor (Color.black);
		    c.setFont (new Font ("TimesRoman", Font.PLAIN, 25));
		    c.drawString ("The pincode you entered is wrong, talk to the the administrator for more information", 120, 150);
		    c.drawImage (wrongpin, 475, 275, null);
		    c.setFont (new Font ("TimesRoman", Font.PLAIN, 30));
		    c.drawString ("Press any button to continue", 380, 535);
		    c.getChar ();

		    AudioPlayer.player.stop (as); // stops all music
		}
		else
		{
		    c.clear ();

		    do
		    {

			check = 0;  //These two values are resetted because when the program loops again the values are the same as they were in the start
			checkhelper = 0; // if the value of checkhelper and check is not 0, the program will terminate once every 4 times the person logs off
			c.clear ();
			c.setColor (Color.gray);
			c.fillRect (0, 0, 1600, 800);
			c.setColor (ATMtheme);
			c.fillRect (75, 75, 966, 550);

			c.setFont (new Font ("TimesRoman", Font.PLAIN, 30));
			c.setColor (Color.white);
			c.fillRoundRect (800, 150, 200, 125, 20, 20);
			c.fillRoundRect (800, 375, 200, 125, 20, 20);
			c.fillRoundRect (115, 375, 200, 125, 20, 20);
			c.fillRoundRect (115, 155, 200, 125, 20, 20);
			c.fillRoundRect (450, 475, 200, 125, 20, 20);

			c.setColor (Color.black);
			c.drawString ("Please select a transaction.", 400, 300);
			c.setColor (Color.black);
			c.setFont (new Font ("TimesRoman", Font.PLAIN, 20));
			c.drawString ("Press 1", 183, 185);
			c.drawString ("To make a deposit", 140, 225);
			c.drawString ("Press 2", 183, 403);
			c.drawString ("To withdraw cash", 140, 445);
			c.drawString ("Press 3", 870, 183);
			c.drawString ("To check bank balance", 810, 225);
			c.drawString ("Press 4", 870, 400);
			c.drawString ("To change your PIN", 820, 445);
			c.drawString ("Press 5", 520, 510);
			c.drawString ("To LOGOUT", 500, 550);
			choice = c.getChar ();

			if (choice == '1')
			{
			    c.clear ();
			    c.setColor (Color.gray);
			    c.fillRect (0, 0, 1600, 800);
			    c.setColor (ATMtheme);
			    c.fillRect (75, 75, 966, 550);
			    Player ("Atm10.wav");
			    AudioPlayer.player.start (as); // starts music
			    c.setColor (Color.black);
			    c.setFont (new Font ("TimesRoman", Font.PLAIN, 30));
			    c.drawString ("Enter the amount of money you are going to deposit then press enter again", 115, 150);
			    c.drawImage (piggybank, 425, 233, null);
			    deposit = c.readInt ();
			    AudioPlayer.player.stop (as); // stops all music

			    if (deposit < 0)
			    {
				Player ("Atm11.wav");
				AudioPlayer.player.start (as); // starts music
				c.clear ();
				c.setColor (Color.gray);
				c.fillRect (0, 0, 1600, 800);
				c.setColor (ATMtheme);
				c.fillRect (75, 75, 966, 550);
				c.setFont (new Font ("TimesRoman", Font.PLAIN, 25));
				c.setColor (Color.black);
				c.drawString ("Cannot deposit negative dollars", 388, 205);
				c.drawImage (wrong, 420, 233, null);
			    }

			    if (deposit > 1000)
			    {
				Player ("Atm11.wav");
				AudioPlayer.player.start (as); // starts music
				c.clear ();
				c.setColor (Color.gray);
				c.fillRect (0, 0, 1600, 800);
				c.setColor (ATMtheme);
				c.fillRect (75, 75, 966, 550);
				c.setFont (new Font ("TimesRoman", Font.PLAIN, 25));
				c.setColor (Color.black);
				c.drawString ("Money deposit should not exceed $1000", 350, 205);
				c.drawImage (wrong, 425, 233, null);
			    }

			    if (deposit == 0)
			    {
				Player ("Atm11.wav");
				AudioPlayer.player.start (as); // starts music
				c.setColor (Color.gray);
				c.fillRect (0, 0, 1600, 800);
				c.setColor (ATMtheme);
				c.fillRect (75, 75, 966, 550);
				c.setFont (new Font ("TimesRoman", Font.PLAIN, 25));
				c.setColor (Color.black);
				c.drawString ("Money deposit not successful", 395, 205);
				c.drawImage (wrong, 425, 233, null);
			    }

			    if (deposit <= 1000 && deposit > 0)
			    {
				c.setColor (Color.gray);
				c.fillRect (0, 0, 1600, 800);
				c.setColor (ATMtheme);
				c.fillRect (75, 75, 966, 550);
				bankbalance = bankbalance + deposit;
				c.setColor (Color.black);
				AudioPlayer.player.stop (as); // stops all music
				Player ("Atmsound2.wav");
				AudioPlayer.player.start (as); // starts music
				c.setFont (new Font ("TimesRoman", Font.PLAIN, 30));
				c.drawString ("Money deposit successful", 393, 175);
				c.drawImage (right, 430, 250, null);
				k = 2;  // This variable is used to check if the withdrawing option is selected for the first time
			    }
			    c.setFont (new Font ("TimesRoman", Font.PLAIN, 30));
			    c.drawString ("Press any button to continue", 380, 550);
			    c.getChar ();
			    c.clear ();
			    AudioPlayer.player.stop (as); // stops all music
			}

			if (choice == '2')
			{
			    if (bankbalance == 0 || k != 2)
			    {
				for (int x = 1 ; x < 2 ; x++) //For loop used to check if withdrawing option is selected for the first time, before the user select the deposit option
				{
				    if (k != 2)
				    {
					c.clear ();
					c.setColor (Color.gray);
					c.fillRect (0, 0, 1600, 800);
					c.setColor (ATMtheme);
					c.fillRect (75, 75, 966, 550);
					c.setColor (Color.black);
					c.setFont (new Font ("TimesRoman", Font.PLAIN, 30));
					c.drawString ("It is required that you deposit an amount before withdrawing for the first time", 100, 175);
					c.setFont (new Font ("TimesRoman", Font.PLAIN, 30));
					c.drawString ("Press any button to continue", 380, 535);
					c.getChar ();
					c.clear ();
				    }
				}
			    }

			    if (k == 2)
			    {
				c.clear ();
				AudioPlayer.player.stop (as); // stops all music
				Player ("Atmsound5.wav");
				AudioPlayer.player.start (as); // starts music
				c.setColor (Color.gray);
				c.fillRect (0, 0, 1600, 800);
				c.setColor (ATMtheme);
				c.fillRect (75, 75, 966, 550);
				c.setColor (Color.black);
				c.setFont (new Font ("TimesRoman", Font.PLAIN, 25));
				c.drawString ("Enter the amount of money you wish to withdraw then press enter again", 180, 150);
				c.drawImage (withdrawal, 450, 265, null);
				withdrawnum = c.readInt ();
				AudioPlayer.player.stop (as); // stops all music

				if (withdrawnum <= 200 && withdrawnum > 0)
				{
				    job.setPrintable (new PrintMoney ());

				    try
				    {
					job.print ();
				    }
				    catch (PrinterException e)
				    {
					c.println ("Printer did not work");
				    }

				    if (withdrawnum > bankbalance)
				    {
					c.clear ();
					AudioPlayer.player.stop (as); // stops all music
					Player ("Atmsound4.wav");
					AudioPlayer.player.start (as); // starts music
					c.setFont (new Font ("TimesRoman", Font.PLAIN, 25));
					c.setColor (Color.gray);
					c.fillRect (0, 0, 1600, 800);
					c.setColor (ATMtheme);
					c.fillRect (75, 75, 966, 550);
					c.setColor (Color.black);
					c.setFont (new Font ("TimesRoman", Font.PLAIN, 25));
					c.drawString ("you withdrew more money than you had in your acccount and now you are in a debt of $" + ((bankbalance - withdrawnum) / -1), 90, 175);
					c.drawImage (angry, 415, 200, null);
					c.setFont (new Font ("TimesRoman", Font.PLAIN, 30));
					c.drawString ("Press any button to continue", 380, 535);
					c.getChar ();
					AudioPlayer.player.stop (as); // stops all music
				    }

				    c.clear ();
				    c.setFont (new Font ("TimesRoman", Font.PLAIN, 25));
				    c.setColor (Color.gray);
				    c.fillRect (0, 0, 1600, 800);
				    c.setColor (ATMtheme);
				    c.fillRect (75, 75, 966, 550);
				    c.setColor (Color.black);
				    c.setFont (new Font ("TimesRoman", Font.PLAIN, 30));
				    c.drawString ("Your transaction is complete", 375, 175);
				    AudioPlayer.player.stop (as); // stops all music
				    Player ("Atmsound2.wav");
				    AudioPlayer.player.start (as); // starts music
				    c.drawImage (right, 430, 250, null);
				    c.setFont (new Font ("TimesRoman", Font.PLAIN, 30));
				    c.drawString ("Press any button to continue", 380, 535);
				    bankbalance = bankbalance - withdrawnum;
				}
				else
				{
				    c.clear ();
				    c.setColor (Color.gray);
				    c.fillRect (0, 0, 1600, 800);
				    c.setColor (ATMtheme);
				    c.fillRect (75, 75, 966, 550);
				    c.setColor (Color.black);

				    if (withdrawnum > 200)
				    {
					AudioPlayer.player.stop (as); // stops all music
					Player ("Atm11.wav");
					AudioPlayer.player.start (as); // starts music
					c.setFont (new Font ("TimesRoman", Font.PLAIN, 30));
					c.drawString ("All ATM's only process $200 or less at a time", 280, 150);
					c.setFont (new Font ("TimesRoman", Font.PLAIN, 30));
					c.drawString ("Press any button to continue", 380, 535);
					c.drawImage (wrong, 405, 200, null);
				    }

				    if (withdrawnum < 0)
				    {
					AudioPlayer.player.stop (as); // stops all music
					Player ("Atm11.wav");
					AudioPlayer.player.start (as); // starts music
					c.drawString ("Printing out negative dollar bills....", 360, 150);
					c.setFont (new Font ("TimesRoman", Font.PLAIN, 30));
					c.drawString ("Press any button to continue", 380, 535);
					c.drawImage (wrong, 405, 200, null);
				    }

				    if (withdrawnum == 0)
				    {
					AudioPlayer.player.stop (as); // stops all music
					Player ("Atm11.wav");
					AudioPlayer.player.start (as); // starts music
					c.drawString ("Printing out air...", 450, 150);
					c.setFont (new Font ("TimesRoman", Font.PLAIN, 30));
					c.drawString ("Press any button to continue", 380, 535);
					c.drawImage (wrong, 405, 200, null);
				    }

				}
				c.getChar ();
				AudioPlayer.player.stop (as); // stops all music
			    }

			    c.clear ();

			}

			if (choice == '3')
			{
			    c.setColor (Color.gray);
			    c.fillRect (0, 0, 1600, 800);
			    c.setColor (ATMtheme);
			    c.fillRect (75, 75, 966, 550);
			    c.setColor (Color.black);

			    if (bankbalance < 0)
			    {
				AudioPlayer.player.stop (as); // stops all music
				Player ("Atmsound4.wav");
				AudioPlayer.player.start (as); // starts music
				c.setFont (new Font ("TimesRoman", Font.PLAIN, 25));
				c.drawString ("You are in a debt of $" + (bankbalance) / -1, 415, 200);
				c.drawImage (piggybank, 425, 200, null);
			    }
			    else
			    {
				c.setFont (new Font ("TimesRoman", Font.PLAIN, 30));
				c.drawString ("Your bank balance is $" + bankbalance, 380, 175);
				c.drawImage (piggybank, 405, 200, null);
			    }

			    c.setFont (new Font ("TimesRoman", Font.PLAIN, 30));
			    c.drawString ("Press any button to continue", 380, 535);
			    c.getChar ();
			    AudioPlayer.player.stop (as); // stops all music
			    c.clear ();
			}

			if (choice == '4')
			{
			    c.clear ();
			    c.setColor (Color.gray);
			    c.fillRect (0, 0, 1600, 800);
			    c.setColor (ATMtheme);
			    c.fillRect (75, 75, 966, 550);

			    c.setColor (Color.black);
			    c.setFont (new Font ("TimesRoman", Font.PLAIN, 30));
			    c.drawString ("Please enter your new pin-code", 365, 170);
			    c.setColor (Color.white);
			    c.fillRect (440, 225, 225, 50);
			    c.setColor (Color.black);
			    c.drawImage (pinicon, 485, 300, null);

			    AudioPlayer.player.stop (as); // stops all music
			    Player ("Atmsound3.wav");
			    AudioPlayer.player.start (as); // starts music
			    c.setFont (new Font ("TimesRoman", Font.PLAIN, 40));
			    pinvalue1 = c.getChar ();
			    c.drawString ("*", 475, 270);
			    pinvalue2 = c.getChar ();
			    c.drawString ("*", 517, 270);
			    pinvalue3 = c.getChar ();
			    c.drawString ("*", 557, 270);
			    pinvalue4 = c.getChar ();
			    c.drawString ("*", 600, 270);
			    c.setFont (new Font ("TimesRoman", Font.PLAIN, 30));
			    c.drawString ("Press any button to continue", 380, 535);
			    c.getChar ();
			    AudioPlayer.player.stop (as); // stops all music
			    c.clear ();
			}
		    }
		    while (choice != '5'); // When choice becomes 5, the program runs the code below
		    c.clear ();
		}
	    }
	}

	c.clear ();
	AudioPlayer.player.stop (as); // stops all music
	Player ("Atm9.wav");
	AudioPlayer.player.start (as); // starts music
	c.setColor (Color.gray);
	c.fillRect (0, 0, 1600, 800);
	c.setColor (ATMtheme);
	c.fillRect (75, 75, 966, 550);
	c.setColor (Color.black);
	c.setFont (new Font ("TimesRoman", Font.PLAIN, 25));
	c.drawString ("PROGRAM WILL NOW TERMINATE DUE TO SECURITY REASONS", 175, 200); //If the pin is entered wrong 4 times in a row the ATM will terminate
	c.drawImage (angry, 400, 275, null);
    }
}


