// The "WS_MoneyLogic" class.
import java.awt.*;
import hsa.Console;

public class WS_MoneyLogic
{
    static Console c;           // The output console

    public static void main (String[] args)
    {
	c = new Console ();

	int num;

	c.println ("Enter");
	num = c.readInt ();

	//Integers declared here
	int dollar100 = num % 100;
	int dollar50 = dollar100 % 50;
	int dollar20 = dollar50 % 20;
	int dollar10 = dollar20 % 10;
	int dollar5 = dollar10 % 5;

	if (num <= 200)
	{
	    c.println ("Processing request...");
	}
	else
	{
	    c.println ("Sorry, transactions cannot exceed $200");
	}

	if (num == 200)
	{
	    c.println ("print two hundred dollar bill");
	}

	if (num == 100)
	{
	    c.println ("Print one hundred dollar bill");
	}

	if (num == 0)
	{
	    c.println ("Printing air");
	}

	if (num < 200 && num > 100)
	{
	    c.println ("Print $100");

	    //Checking to see if input number is more or less than 50
	    if (dollar100 >= 50)
	    {
		c.println ("Print $50 now");
	    }
	    else
	    {
		c.println ("Do not print $50");
	    }

	    //Checking to see if the input number is more or less than 20
	    if (dollar50 >= 20)
	    {
		c.println ("Print $20 now");
	    }
	    else
	    {
		c.println ("Do not print $20");
	    }

	    //Checking to see if the input number is more or less than 10
	    if (dollar20 >= 10)
	    {
		c.println ("Print $10 now");
	    }
	    else
	    {
		c.println ("Do not print $10");
	    }

	    //Checking to see if the input number is more or less than 5
	    if (dollar10 >= 5)
	    {
		c.println ("Print $5 now");
	    }
	    else
	    {
		c.println ("Do not print $5");
	    }

	    //Adding all the dollar bills will make 185 (100 + 50 + 20 + 10 + 5 = 185)
	    //so the code cannot print bills that make $185-$195
	    //this code is a solution to that problem

		if (num >= 190 && num <= 194)
		{
		    c.println ("print 20 dollars now");
		}
		if (num >= 195 && num <= 199)
		{
		    c.println ("print 20 dollars now");
		}
		if (num >= 145 && num <= 149)
		{   
		   c.println ("Print 20 dollars now");
		}
		if (num >= 140 && num <= 144)
		{
		    c.println ("Print 20 dollars now");
		}
	    
	}
	else
	{
	    //Checking to see if input number is more or less than 50
	    if (dollar100 >= 50)
	    {
		c.println ("Print $50 now");
	    }
	    else
	    {
		c.println ("Do not print $50");
	    }

	    //Checking to see if the input number is more or less than 20
	    if (dollar50 >= 20)
	    {
		c.println ("Print $20 now");
	    }
	    else
	    {
		c.println ("Do not print $20");
	    }

	    //Checking to see if the input number is more or less than 10
	    if (dollar20 >= 10)
	    {
		c.println ("Print $10 now");
	    }
	    else
	    {
		c.println ("Do not print $10");
	    }

	    //Checking to see if the input number is more or less than 5
	    if (dollar10 >= 5)
	    {
		c.println ("Print $5 now");
	    }
	    else
	    {
		c.println ("Do not print $5");
	    }

	    //Adding all the dollar bills will make 185 (50 + 20 + 10 + 5 = 85)
	    //so the code cannot print bills that make $185-$195
	    //this code is a solution to that problem

		if (num >= 90 && num <= 94)
		{
		    c.println ("print 20 dollars now");
		}
		if (num >= 95 && num <= 99)
		{
		    c.println ("print 20 dollars now");
		}
		if (num >= 45 && num <= 49)
		{   
		   c.println ("Print 20 dollars now");
		}
		if (num >= 40 && num <= 44)
		{
		    c.println ("Print 20 dollars now");
		}
	    
	}
    }
}



