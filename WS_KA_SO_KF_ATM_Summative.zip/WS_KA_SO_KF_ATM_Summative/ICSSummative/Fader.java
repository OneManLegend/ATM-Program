import java.awt.*;
import hsa.Console;

public class Fader
{
    static Console c;

    public static void main (String[] args)
    {
	c = new Console ();

	//Fader algorithm Starts here

	Color grass = new Color (10, 200, 0);
	int colperameter = 255;

	double red = 0, green = 0, blue = 0;


	for (int perameter = 0 ; perameter <= 10000 ; perameter++)  //This loops a 10000 times so i divided the ATMtheme's Red, Green, Blue values separately with 10000
	{
	    int redint = (int) (red + 0.5);         //Converts the double variable to an integer so that it can be used as an RGB value
	    int greenint = (int) (green + 0.5);
	    int blueint = (int) (blue + 0.5);

	    Color ATMtheme = new Color (redint, greenint, blueint);
	    c.setColor (ATMtheme);
	    c.fillRect (75, 75, 966, 550);

	    red = red + 0.0075;     //every time the program loops (10000 times), this value is added to the previous value of the RGB colors
	    green = green + 0.0125; //The smaller the added number is, the slower the black image fades out
	    blue = blue + 0.0225;
	}
	
	//Fader algorithm Starts here
    }
}


